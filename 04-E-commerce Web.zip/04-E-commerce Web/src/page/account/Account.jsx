import React from 'react'
import Myimage from "/Screenshot2026-05-01171932.png";
import { FaSearch } from "react-icons/fa";
import { MdFavoriteBorder } from "react-icons/md";
import { FaShoppingCart } from "react-icons/fa";
import { Link } from "react-router-dom";
function account() {
  return (
    <div>                            <h1 className="h1">
                  Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%! Shop
                  Now English{" "}
                  EXCLUSIVE <Link to="/home">Home</Link> <Link to="/home/about">About</Link> <Link to="/home/sign-up">Sign-Up</Link> <Link to="/home/contact">Contact</Link> <input type="text" placeholder="Search for products..." /> <FaSearch />  
                  <Link to="/home/favorites"><MdFavoriteBorder /></Link> <Link to="/home/cart"><FaShoppingCart /></Link>
                </h1>
          your profile
          name:mahmoud tafour
          email:m.********@*****.com
          address: 111 bijoy sarani, dhaka, dh 1515, bangladesh

          <h3>Edit your profile</h3>
   <input type="text" placeholder="Enter your First name" />
      <input type="text" placeholder="Enter your Last name" />
      <input type="radio" placeholder="Gender:Male" /> 
      <input type="radio" placeholder="Gender:FeMale" /> 
      <input type="radio" placeholder="Gender:Rather Donot Say" />
      <input type="text" placeholder="Enter your address" />
      <input type="text" placeholder="Enter your email" />
      <input type="text" placeholder="Enter your phone number" />

        Password Changes(
        <input type="text" placeholder="   Current Password: " />
        <input type="text" placeholder="     New Password:" />
        <input type="text" placeholder=" Confirm New Password:" />
        )
        <button>Cancel Changes</button>
        <button>Save Changes</button>
           
                      <footer>
                                   <h4>Exslusive</h4>
                                   <h6>Subscribe</h6>
                                   <p>Get 70% offer on your first order</p>
                                   <input type="email" placeholder="Enter your email" id="email"/>
                             <h4>Support</h4>
                             <p>+88015-88888-9999
                             111 Bijoy sarani, Dhaka,  DH 1515, Bangladesh.
                             exclusive@gmail.com
                             </p>
                             <h4>Account</h4>
                             <p>
                             <Link to="/home/account">Account</Link>
                             <Link to="/home/cart">Cart</Link>
                             <Link to="/home/login">Login / Register</Link>
                             <Link to="/home/account">Wishlist</Link>
                             <Link to="/home/account">Shop</Link>
                             </p>
                             <h4>Quick Link</h4>
                             <Link to="/home/about">Terms of Use</Link>
                             <Link to="/home/about">Privacy Policy</Link>
                             <Link to="/home/contact">Contact</Link>
                             <Link to="/home/about">Faqs</Link>
                             <h4>Download App</h4>
                             <p>Save $3 with App New User Only</p>
                             <img src={Myimage} alt="Picture of downloading programs and social medias websites" />
                             <p>&copy; Copyright Rimel 2026. All right reserved</p>
                                 </footer></div>
  )
}

export default account