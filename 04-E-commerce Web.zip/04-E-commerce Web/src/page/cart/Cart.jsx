import Myimage from "/Screenshot2026-05-01171932.png";
import React from "react";
import cartItems from "./Cart";
import { FaSearch } from "react-icons/fa";
import { MdFavoriteBorder } from "react-icons/md";
import { FaShoppingCart } from "react-icons/fa";
import "./cart.module.css";
import PageTransition from "../../components/PageTransition";
 import  { useContext } from 'react'
 import { CartContext } from '../../components/context/CartContext'
import { FaTrashAlt } from "react-icons/fa";
import { Link } from "react-router-dom";

function Cart() {
    const totalItems = (cartItems || []).reduce((acc, item) => acc + item.quantity, 0);

    const {cartItems , increaseQuantity , decreaseQuantity , removeFromCart} = useContext(CartContext)
    console.log(cartItems);

    const total = cartItems.reduce((acc , item) => acc + item.price * item.quantity, 0)
  return (
     <PageTransition>
    <div>
                 <h1 className="h1">
              Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%! Shop
              Now English{" "}
              EXCLUSIVE <Link to="/home">Home</Link> <Link to="/home/about">About</Link> <Link to="/home/sign-up">Sign-Up</Link> <Link to="/home/contact">Contact</Link> <input type="text" placeholder="Search for products..." /> <FaSearch />  
              <Link to="/home/favorites"><MdFavoriteBorder /></Link> <Link to="/home/cart"><FaShoppingCart /></Link>
            </h1>
      <h1> My Cart</h1>
      <p>This is what you buy</p>
 
        <div>
        <div>
            <h1>Order Summary</h1>

            <div >
                {cartItems.length === 0 ? (
                    <p>Your Cart is empty.</p>
                ) : (
                    cartItems.map((item, index) => (
                        <div  key={index}>
                            <div >
                                <div >
                                <img src={item.images[0]} alt="" />
                                </div>

                                <div >
                                    <h4>{item.title}</h4>
                                    <p>${item.price}</p>

                                    <div >
                                        <button onClick={() => decreaseQuantity(item.id)}>-</button>
                                        <span >{item.quantity}</span>
                                        <button onClick={() => increaseQuantity(item.id)}>+</button>
                                    </div>
                                </div>

                            </div>
                                 <button onClick={() => removeFromCart(item.id)} className='delete_item'><FaTrashAlt /></button>
                        </div>
                    ))
                )}
            </div>


            <div className="bottom_summary">
                <div className="shop_table">
                    <p>Total:</p>
                    <span className='total_checkout'>${total.toFixed(2)}</span>
                </div>

                <div className="button_div">
                    <input type="text" placeholder="Coupon Code" />
                       <button type='submit'>Apply Coupon</button>
                    <button type='submit' href="/home/checkout">Update Cart</button>
                    <button type='submit' href="/home/wishlist">Continue Shopping</button>
                    <button type='submit' href="/home">Go BACK TO HOME</button>
                </div>
            </div>
        </div>
    </div>
    
           <footer>
                        <h4>Exslusive</h4>
                        <h6>Subscribe</h6>
                        <p>Get 70% offer on your first order</p>
                        <input type="email" placeholder="Enter your email" id="email"/>
                  <h4>Support</h4>
                  <p>+88015-88888-9999
                  111 Bijoy sarani, Dhaka,  DH 1515, Bangladesh.
                  exclusive@gmail.com
                  </p>
                  <h4>Account</h4>
                  <p>
                  <Link to="/home/account">Account</Link>
                  <Link to="/home/cart">Cart</Link>
                  <Link to="/home/login">Login / Register</Link>
                  <Link to="/home/account">Wishlist</Link>
                  <Link to="/home/account">Shop</Link>
                  </p>
                  <h4>Quick Link</h4>
                  <Link to="/home/about">Terms of Use</Link>
                  <Link to="/home/about">Privacy Policy</Link>
                  <Link to="/home/contact">Contact</Link>
                  <Link to="/home/about">Faqs</Link>
                  <h4>Download App</h4>
                  <p>Save $3 with App New User Only</p>
                  <img src={Myimage} alt="Picture of downloading programs and social medias websites" />
                  <p>&copy; Copyright Rimel 2026. All right reserved</p>
                      </footer>
    </div>
    </PageTransition>
  );
}

export default Cart;
