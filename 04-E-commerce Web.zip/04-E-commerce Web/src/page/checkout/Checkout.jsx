import Myimage from "/Screenshot2026-05-01171932.png";
import "./checkout.module.css";
import { FaSearch } from "react-icons/fa";
import { MdFavoriteBorder } from "react-icons/md";
import { FaShoppingCart } from "react-icons/fa";
import React from 'react'
import { Link } from "react-router-dom";
function checkout() {
  return (
    <div>
                 <h1 className="h1">
              Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%! Shop
              Now English{" "}
              EXCLUSIVE <Link to="/home">Home</Link> <Link to="/home/about">About</Link> <Link to="/home/sign-up">Sign-Up</Link> <Link to="/home/contact">Contact</Link> <input type="text" placeholder="Search for products..." /> <FaSearch />  
              <Link to="/home/favorites"><MdFavoriteBorder /></Link> <Link to="/home/cart"><FaShoppingCart /></Link>
            </h1>
      <input type="text" placeholder="First Name" />
      <input type="text" placeholder="Last Name" />
      <input type="text" placeholder="Street Address" />
        <input type="text" placeholder=" Building,home,floor" />
        <input type="text" placeholder=" Email" />
         <input type="text" placeholder="Town/City" />
      <input type="number" placeholder="Post Code" />
      <input type="number" placeholder="Phone Number" />
   
    
          

         
                        <div  key={index}>
                           
                                <div >
                                <img src={item.images[0]} alt="" />
                                </div>

                                <div >
                                    <h4>{item.title}</h4>
                                    <p>${item.price}</p>
          
                         </div>
                         </div>
                <div className="shop_table">
                    <p>Total:</p>
                  <span className='total_checkout'>${total.toFixed(2)}</span>
                </div>

              
 
        <input type="checkbox"  />
        <p>Save this information for faster-chechout next time.</p>
      <input type="radio" placeholder="Cash on Delivery" />
       <input type="radio" placeholder="Pay by Mada" />
       <input type="radio" placeholder="Pay by Visa" />
       <input type="radio" placeholder="Pay by MasterCard" />
       <input type="radio" placeholder="Visa  on Delivery" />
       <input type="radio" placeholder="Pay by Apple Pay" />
       <input type="radio" placeholder="Pay by Samsung Pay" />
       <input type="radio" placeholder="Pay by Microsoft Pay" />
        <input type="text" placeholder="Coupon Code" />
        <button type='submit'>Apply Coupon</button>
        <button href="/home/account">Place Order</button>
   
           <footer>
                        <h4>Exslusive</h4>
                        <h6>Subscribe</h6>
                        <p>Get 70% offer on your first order</p>
                        <input type="email" placeholder="Enter your email" id="email"/>
                  <h4>Support</h4>
                  <p>+88015-88888-9999
                  111 Bijoy sarani, Dhaka,  DH 1515, Bangladesh.
                  exclusive@gmail.com
                  </p>
                  <h4>Account</h4>
                  <p>
                  <Link to="/home/account">Account</Link>
                  <Link to="/home/cart">Cart</Link>
                  <Link to="/home/login">Login / Register</Link>
                  <Link to="/home/account">Wishlist</Link>
                  <Link to="/home/account">Shop</Link>
                  </p>
                  <h4>Quick Link</h4>
                  <Link to="/home/about">Terms of Use</Link>
                  <Link to="/home/about">Privacy Policy</Link>
                  <Link to="/home/contact">Contact</Link>
                  <Link to="/home/about">Faqs</Link>
                  <h4>Download App</h4>
                  <p>Save $3 with App New User Only</p>
                  <img src={Myimage} alt="Picture of downloading programs and social medias websites" />
                  <p>&copy; Copyright Rimel 2026. All right reserved</p>
                      </footer>
     </div>
  )
}

export default checkout