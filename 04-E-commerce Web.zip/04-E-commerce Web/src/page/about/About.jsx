import Myimage from "/Screenshot2026-05-01171932.png";
import React from "react";
import { FaSearch } from "react-icons/fa";
import { FaShoppingCart } from "react-icons/fa";
import { MdFavoriteBorder } from "react-icons/md";
import { Link } from "react-router-dom";
function about() {
  return (
    <div>
                 <h1 className="h1">
              Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%! Shop
              Now English{" "}
              EXCLUSIVE <Link to="/home">Home</Link> <Link to="/home/about">About</Link> <Link to="/home/sign-up">Sign-Up</Link> <Link to="/home/contact">Contact</Link> <input type="text" placeholder="Search for products..." /> <FaSearch />  
              <Link to="/home/favorites"><MdFavoriteBorder /></Link> <Link to="/home/cart"><FaShoppingCart /></Link>
            </h1>
      <h1>About Us</h1>
    <p>Launced in 2015, Exclusive is South Asia’s premier online shopping makterplace with an active presence in Bangladesh. Supported by wide range of tailored marketing, data and service solutions, Exclusive has 10,500 sallers and 300 brands and serves 3 millioons customers across the region. 
Exclusive has more than 1 Million products to offer, growing at a very fast. Exclusive offers a diverse assotment in categories ranging  from consumer.</p>
      <img src="../../Screenshot 2026-05-26 233503" alt="blank" />
      <p></p>
      <img src="../../Screenshot 2026-05-26 233555" alt="information" />
      <p></p>
      <img src="../../Screenshot 2026-05-26 233653" alt="information" />
      <p></p>
      <img src="../../Screenshot 2026-05-26 223428" alt="information" /> 

           <footer>
                        <h4>Exslusive</h4>
                        <h6>Subscribe</h6>
                        <p>Get 70% offer on your first order</p>
                        <input type="email" placeholder="Enter your email" id="email"/>
                  <h4>Support</h4>
                  <p>+88015-88888-9999
                  111 Bijoy sarani, Dhaka,  DH 1515, Bangladesh.
                  exclusive@gmail.com
                  </p>
                  <h4>Account</h4>
                  <p>
                  <Link to="/home/account">Account</Link>
                  <Link to="/home/cart">Cart</Link>
                  <Link to="/home/login">Login / Register</Link>
                  <Link to="/home/account">Wishlist</Link>
                  <Link to="/home/account">Shop</Link>
                  </p>
                  <h4>Quick Link</h4>
                  <Link to="/home/about">Terms of Use</Link>
                  <Link to="/home/about">Privacy Policy</Link>
                  <Link to="/home/contact">Contact</Link>
                  <Link to="/home/about">Faqs</Link>
                  <h4>Download App</h4>
                  <p>Save $3 with App New User Only</p>
                  <img src={Myimage} alt="Picture of downloading programs and social medias websites" />
                  <p>&copy; Copyright Rimel 2026. All right reserved</p>
                      </footer>
    </div>
  );
}

export default about;
