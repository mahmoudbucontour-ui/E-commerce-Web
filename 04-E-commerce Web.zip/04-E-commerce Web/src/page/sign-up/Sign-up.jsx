import "./Sign-up.module.css";
import React from 'react'
import Myimage from "/Screenshot2026-05-01171932.png";
import { Link } from "react-router-dom";
import { FaSearch } from "react-icons/fa";
import { MdFavoriteBorder } from "react-icons/md";
import { FaShoppingCart } from "react-icons/fa";
<Link
  rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"
/>;
function Signup() {
  return(
  <div>
                 <h1 className="h1">
              Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%! Shop
              Now English{" "}
              EXCLUSIVE <Link to="/home">Home</Link> <Link to="/home/about">About</Link> <Link to="/home/sign-up">Sign-Up</Link> <Link to="/home/contact">Contact</Link> <input type="text" placeholder="Search for products..." /> <FaSearch />  
              <Link to="/home/favorites"><MdFavoriteBorder /></Link> <Link to="/home/cart"><FaShoppingCart /></Link>
            </h1>
<h2>Create An Account</h2>
<h6>Enter your details below</h6>
 <form className="addUserForm">
        <div className="inputGroup">
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            name="name"
            autoComplete="off"
            placeholder="Enter your name"
          />
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            autoComplete="off"
            placeholder="Enter your Email"
          />
          <label htmlFor="Password">Password:</label>
          <input
            type="password"
            id="password"
            name="password"
            autoComplete="off"
            placeholder="Enter Password"
          />
          <button type="submit" href="/home" className="btn btn-success">
            Sign Up
          </button>
        </div>
      </form>
      <div className="login">
        <p>Already have an Account? </p>
        <Link to="/home/log-in" type="submit" className="btn btn-primary">
          Login
        </Link>
        </div>
<button>Create Account</button>
<button href="https://accounts.google.com/v3/signin/accountchooser?access_type=offline&client_id=1062019541050-8mvc17gv9c3ces694hq5k1h6uqio1cfn.apps.googleusercontent.com&code_challenge=s29nDruCs4APcLCn6zGihW00691tIepNhauqPgpa8Is&code_challenge_method=S256&redirect_uri=https%3A%2F%2Fmiro.com%2Foauth%2Fsocial%2Fgoogle%2Fcallback%2F&response_type=code&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fcontacts.readonly+profile+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fdirectory.readonly+email&state=eyAicmV0dXJuX21ldGhvZCI6IiIsICJjc3JmX3Rva2VuIjpudWxsLCAib2F1dGhfc3RhdGUiOiJld29nSUNKemRHRjBaU0lnT2lBaVkzVmFORzlKT0d0QlNFSjVjVzlRTldOclpHUTBaak13TVdabU5DSUtmUT09IiwgInNvdXJjZV9wYWdlIjoiU0lHTlVQIiB9&dsh=S-1993014381%3A1779825747516330&o2v=1&service=lso&flowName=GeneralOAuthFlow&opparams=%253F&continue=https%3A%2F%2Faccounts.google.com%2Fsignin%2Foauth%2Fconsent%3Fauthuser%3Dunknown%26part%3DAJi8hAP3XuSzPvBLXFuzMuef9Zdm0QpXt30qSvkjD11OjtrVxs6EHhcaewoWVkKBj2s6054hQimLKNPivbmUwebDp06JWfmfGuSjK6uj2mwSMNvd26hGx5muZYLSDOTa5CGSKC7x2lCObgMlB_brQCzAMKtk7rJ1r874HG155v2BheKTRBUcA_I0TKVxtzjz0NMgoflANC8E5AcIKVbWArIuStp3JlSzCvOWdaKsj8Fid61DXZ0_mRr1l-jfSjGI11xUSt5Tje8AhlF4iFhYpvxRlMfltWfxIYApxoarj7nn2RKn67C2oW9URC0fr1IaYHNV1cLQttCv_R-4Dh72jS3Rj7wuu2lw7udnDJCQYkSvZpHDz1bOuYWblseZ8EG9kOrHlEyjtonZDEC6ZqZNcZQ-l8fa4QuS1om3R-ovjGDzMPFKCBzSv5uXyMhiY5nRfWgVXmkkNO-1Eri57XvId6S_Ns952v4oSyPk4e-7KEXR-3CbeJesCZ8%26flowName%3DGeneralOAuthFlow%26as%3DS-1993014381%253A1779825747516330%26client_id%3D1062019541050-8mvc17gv9c3ces694hq5k1h6uqio1cfn.apps.googleusercontent.com%26requestPath%3D%252Fsignin%252Foauth%252Fconsent%23&app_domain=https%3A%2F%2Fmiro.com">Sign In with Google</button>
<p>Already have an account? <Link to="/login">Login</Link></p>
           <footer>
                        <h4>Exslusive</h4>
                        <h6>Subscribe</h6>
                        <p>Get 70% offer on your first order</p>
                        <input type="email" placeholder="Enter your email" id="email"/>
                  <h4>Support</h4>
                  <p>+88015-88888-9999
                  111 Bijoy sarani, Dhaka,  DH 1515, Bangladesh.
                  exclusive@gmail.com
                  </p>
                  <h4>Account</h4>
                  <p>
                  <Link to="/home/account">Account</Link>
                  <Link to="/home/cart">Cart</Link>
                  <Link to="/home/login">Login / Register</Link>
                  <Link to="/home/account">Wishlist</Link>
                  <Link to="/home/account">Shop</Link>
                  </p>
                  <h4>Quick Link</h4>
                  <Link to="/home/about">Terms of Use</Link>
                  <Link to="/home/about">Privacy Policy</Link>
                  <Link to="/home/contact">Contact</Link>
                  <Link to="/home/about">Faqs</Link>
                  <h4>Download App</h4>
                  <p>Save $3 with App New User Only</p>
                  <img src={Myimage} alt="Picture of downloading programs and social medias websites" />
                  <p>&copy; Copyright Rimel 2026. All right reserved</p>
                      </footer>
    </div>
  )
}
export default Signup
