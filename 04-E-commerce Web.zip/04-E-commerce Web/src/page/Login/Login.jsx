import "./Login.module.css";
import Myimage from "/Screenshot2026-05-01171932.png";
import { Link } from "react-router-dom";
import { FaSearch } from "react-icons/fa";
import { MdFavoriteBorder } from "react-icons/md";
import { FaShoppingCart } from "react-icons/fa";
import React from 'react'
<link
  rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"
/>;
function Login() {
  return(
  <div>
                 <h1 className="h1">
              Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%! Shop
              Now English{" "}
              EXCLUSIVE <Link to="/home">Home</Link> <Link to="/home/about">About</Link> <Link to="/home/sign-up">Sign-Up</Link> <Link to="/home/contact">Contact</Link> <input type="text" placeholder="Search for products..." /> <FaSearch />  
              <Link to="/home/favorites"><MdFavoriteBorder /></Link> <Link to="/home/cart"><FaShoppingCart /></Link>
            </h1>
<img src="img/Screenshot 2026-05-26 231719.png" alt="Picture of downloading programs and social medias websites" />
<h2>Login to your Account</h2>
<h6>Enter your details below</h6>
<form className="addUserForm">
        <div className="inputGroup">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            autoComplete="off"
            placeholder="Enter your Email"
          />
          <label htmlFor="Password">Password:</label>
          <input
            type="password"
            id="password"
            name="password"
            autoComplete="off"
            placeholder="Enter your Password"
          />
          <button type="submit" class="btn btn-primary">
            Login
          </button>
        </div>
      </form>
      <div className="login">
        <p>Don't have Account? </p>
        <Link to="/home/sign-up" type="submit" class="btn btn-success">
          Sign Up
        </Link>
        </div>
<button href="/home">Login to Account</button>
<button href="">Forgot Password?</button>
<button href="">Sign In with Google</button>
<p>Already have an account? <Link to="/login">Login</Link></p>
                    <footer>
                                 <h4>Exslusive</h4>
                                 <h6>Subscribe</h6>
                                 <p>Get 70% offer on your first order</p>
                                 <input type="email" placeholder="Enter your email" id="email"/>
                           <h4>Support</h4>
                           <p>+88015-88888-9999
                           111 Bijoy sarani, Dhaka,  DH 1515, Bangladesh.
                           exclusive@gmail.com
                           </p>
                           <h4>Account</h4>
                           <p>
                           <Link to="/home/account">Account</Link>
                           <Link to="/home/cart">Cart</Link>
                           <Link to="/home/login">Login / Register</Link>
                           <Link to="/home/account">Wishlist</Link>
                           <Link to="/home/account">Shop</Link>
                           </p>
                           <h4>Quick Link</h4>
                           <Link to="/home/about">Terms of Use</Link>
                           <Link to="/home/about">Privacy Policy</Link>
                           <Link to="/home/contact">Contact</Link>
                           <Link to="/home/about">Faqs</Link>
                           <h4>Download App</h4>
                           <p>Save $3 with App New User Only</p>
                           <img src={Myimage} alt="Picture of downloading programs and social medias websites" />
                           <p>&copy; Copyright Rimel 2026. All right reserved</p>
                               </footer>
    </div>
  )
}
export default Login