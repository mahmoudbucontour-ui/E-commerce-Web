import "/src/index.css";
import Contact from "../contact/Contact.jsx";
import Cart from "../cart/Cart.jsx";
import ScrollToTop from "../../components/Scroll-to-top/ScrollToTop.jsx";
import About from "../about/About.jsx";
import SearchResults from "../SearchResults.jsx";
import Favorites from "../favorites/Favorites.jsx";
import Signup from "../sign-up/Sign-up.jsx";
import HeroSlider from './../../HeroSlider';
import Myimage from "/Screenshot2026-05-01171932.png";
import { FaArrowCircleRight } from "react-icons/fa";
import { FaArrowCircleLeft } from "react-icons/fa";
import { FaSearch } from "react-icons/fa";
import { MdFavoriteBorder } from "react-icons/md";
import { FaShoppingCart } from "react-icons/fa";
import React, { useEffect, useState } from "react";
import "./home.module.css";
import SlideProduct from "../../components/slideProducts/SlideProduct";
import SlideProductLoading from "../../components/slideProducts/SlideProductLoading";
import PageTransition from "../../components/PageTransition";
import { Link } from "react-router-dom";
const categories = [
  "smartphones",
  "mobile-accessories",
  "laptops",
  "tablets",
  "sunglasses",
  "sports-accessories",
];
function Home() {
  
 const [products, setProducts] = useState({});

  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const results = await Promise.all(
          categories.map(async (category) => {
            const res = await fetch(
              `https://dummyjson.com/products/category/${category}`
            );
            const data = await res.json();
            return { [category]: data.products };
          })
        );

        const productsData = Object.assign({}, ...results);
        setProducts(productsData);
      } catch (error) {
        console.error("error Fetching", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);
  return (
     <PageTransition>
    <div>
                 <h1 className="h1">
              Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%! Shop
              Now English{" "}
              EXCLUSIVE <Link to="/home">Home</Link> <Link to="/home/about">About</Link> <Link to="/home/sign-up">Sign-Up</Link> <Link to="/home/contact">Contact</Link> <input type="text" placeholder="Search for products..." /> <FaSearch />  
              <Link to="/home/favorites"><MdFavoriteBorder /></Link> <Link to="/home/cart"><FaShoppingCart /></Link>
            </h1>
      <HeroSlider />
      <Contact />
      <About />
      <Signup />
      <SearchResults />
      <Favorites />
      <Cart />
      <ScrollToTop />

      <p className="Categories">
<Link to="/home/categorypage/:id">Woman's Fashion</Link>  <br/>
<Link to="/home/categorypage/:id">Men's Fashion</Link>  <br/>
<Link to="/home/categorypage/:id">Electronics</Link>  <br/>
<Link to="/home/categorypage/:id">Home & Lifestyle</Link> <br/>
<Link to="/home/categorypage/:id">Medicine</Link>  <br/>
<Link to="/home/categorypage/:id">Sports & Outdoor</Link>  <br/>
<Link to="/home/categorypage/:id">Baby & Toys</Link> <br/>
<Link to="/home/categorypage/:id">Groceries & Pets </Link>  <br/>
<Link to="/home/categorypage/:id">Health & Beauty</Link> <br/>
<Link to="/home/categorypage/:id">Sunglases</Link> <br />
      </p>
      FLASH SALE
      <p className="flash_sale">
        Up to 70% off | Free Shipping
      </p>
       DAYS   HOURS   MINUTES  SECONDS
       03   :   15  :   22   :  19
        <div className="button-container">
         <FaArrowCircleLeft />   <button type="button" className="btn" onClick={() => alert('Left clicked!')}>&#8592; Left</button>
      <FaArrowCircleRight />  <button type="button" className="btn" onClick={() => alert('Right clicked!')} >Right &#8594;</button>
    </div>
       
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <button href="/home/wishlist">VIEW ALL PRODUCTS</button>
       <h5>categories</h5>
       <h3>Search By Categories</h3>
        <div className="button-container">
         <FaArrowCircleLeft />   <button type="button" className="btn" onClick={() => alert('Left clicked!')}>&#8592; Left</button>
      <FaArrowCircleRight />  <button type="button" className="btn" onClick={() => alert('Right clicked!')} >Right &#8594;</button>
    </div>
       <div>Phones</div>
       <div>Computers</div>
       <div>smartwatches</div>
       <div>Cameras</div>
       <div>Microphones</div>
       <div>Headphones</div>
       <div>Gaming</div>
       <h5>This Month</h5>
       <h3>Best Selling Products</h3>
       <button href="/home/wishlist">VIEW ALL PRODUCTS</button>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <img src="img/Screenshot 2026-05-26 222915.png" alt="A picture of music tool" />
       <h5>Our Products</h5>
       <h3>Explore Our Products</h3>
           <div className="button-container">
         <FaArrowCircleLeft />   <button type="button" className="btn" onClick={() => alert('Left clicked!')}>&#8592; Left</button>
      <FaArrowCircleRight />  <button type="button" className="btn" onClick={() => alert('Right clicked!')} >Right &#8594;</button>
    </div> 
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <div> {loading
          ? categories.map((category) => <SlideProductLoading key={category} />)
          : categories.map((category) => (
              <SlideProduct
                key={category}
                data={products[category]}
                title={category.replace("-", " ")}
              />
            ))}</div>
       <button href="/home/wishlist">VIEW ALL PRODUCTS</button>
       <img src="img/Screenshot 2026-05-26 223456" alt="picture of new arrival" />
       <img src="img/Screenshot 2026-05-26 223428" alt="picture of advantages" />
            <footer>
                        <h4>Exslusive</h4>
                        <h6>Subscribe</h6>
                        <p>Get 70% offer on your first order</p>
                        <input type="email" placeholder="Enter your email" id="email"/>
                  <h4>Support</h4>
                  <p>+88015-88888-9999
                  111 Bijoy sarani, Dhaka,  DH 1515, Bangladesh.
                  exclusive@gmail.com
                  </p>
                  <h4>Account</h4>
                  <p>
                  <Link to="/home/account">Account</Link>
                  <Link to="/home/cart">Cart</Link>
                  <Link to="/home/login">Login / Register</Link>
                  <Link to="/home/account">Wishlist</Link>
                  <Link to="/home/account">Shop</Link>
                  </p>
                  <h4>Quick Link</h4>
                  <Link to="/home/about">Terms of Use</Link>
                  <Link to="/home/about">Privacy Policy</Link>
                  <Link to="/home/contact">Contact</Link>
                  <Link to="/home/about">Faqs</Link>
                  <h4>Download App</h4>
                  <p>Save $3 with App New User Only</p>
                  <img src={Myimage} alt="Picture of downloading programs and social medias websites" />
                  <p>&copy; Copyright Rimel 2026. All right reserved</p>
                      </footer>
  </div>
  </PageTransition>
  );
};
export default Home