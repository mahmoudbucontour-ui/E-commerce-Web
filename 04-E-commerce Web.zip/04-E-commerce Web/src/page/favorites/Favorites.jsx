import Myimage from "/Screenshot2026-05-01171932.png";
import React from "react";
import { FaSearch } from "react-icons/fa";
import { MdFavoriteBorder } from "react-icons/md";
import { FaShoppingCart } from "react-icons/fa";
import "./favorites.module.css";
import { useContext } from 'react'
import { CartContext } from '../../components/context/CartContext'
import PageTransition from '../../components/PageTransition'
import Product from '../../components/slideProducts/Product'
import favorites from "./Favorites.jsx"
import { Link } from "react-router-dom";
function Favorites() {
 const {favorites} = useContext(CartContext)
  return (
    <div>
        
                 <h1 className="h1">
              Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%! Shop
              Now English{" "}
              EXCLUSIVE <Link to="/home">Home</Link> <Link to="/home/about">About</Link> <Link to="/home/sign-up">Sign-Up</Link> <Link to="/home/contact">Contact</Link> <input type="text" placeholder="Search for products..." /> <FaSearch />  
              <Link to="/home/favorites"><MdFavoriteBorder /></Link> <Link to="/home/cart"><FaShoppingCart /></Link>
            </h1>
      <h1>My Favorites</h1>
       <PageTransition >
        <div className="category_products FavoritesPage">
            <div className="container">
                <div className="top_slide">
                    <h2>Your Favorites</h2>
                </div>

                {favorites.length === 0 ? (
                    <p>No Favorites Products yet.</p>
                ) : (
                    <div className="products">
                        {favorites.map(item => (
                            <Product item={item} key={item.id} />
                        ))}
                    </div>
                )}
            </div>
        </div>
    </PageTransition>
                      <footer>
                        <h4>Exslusive</h4>
                        <h6>Subscribe</h6>
                        <p>Get 70% offer on your first order</p>
                        <input type="email" placeholder="Enter your email" id="email"/>
                  <h4>Support</h4>
                  <p>+88015-88888-9999
                  111 Bijoy sarani, Dhaka,  DH 1515, Bangladesh.
                  exclusive@gmail.com
                  </p>
                  <h4>Account</h4>
                  <p>
                  <Link to="/home/account">Account</Link>
                  <Link to="/home/cart">Cart</Link>
                  <Link to="/home/login">Login / Register</Link>
                  <Link to="/home/account">Wishlist</Link>
                  <Link to="/home/account">Shop</Link>
                  </p>
                  <h4>Quick Link</h4>
                  <Link to="/home/about">Terms of Use</Link>
                  <Link to="/home/about">Privacy Policy</Link>
                  <Link to="/home/contact">Contact</Link>
                  <Link to="/home/about">Faqs</Link>
                  <h4>Download App</h4>
                  <p>Save $3 with App New User Only</p>
                  <img src={Myimage} alt="Picture of downloading programs and social medias websites" />
                  <p>&copy; Copyright Rimel 2026. All right reserved</p>
                      </footer>
    </div>
  );
}

export default Favorites;
