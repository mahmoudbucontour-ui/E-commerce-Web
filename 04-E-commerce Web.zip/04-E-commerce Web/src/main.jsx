import React from "react";
import ReactDOM from "react-dom/client";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";
import { createBrowserRouter, RouterProvider, BrowserRouter } from "react-router-dom";
import "./index.css";
import About from "./page/about/About.jsx";
import SearchResults from "./page/SearchResults";
import Favorites from "./page/favorites/Favorites";
import Home from "./page/home/Home";
import Contact from "./page/contact/Contact.jsx";
import Cart from "./page/cart/Cart.jsx";
import Signup from "./page/sign-up/Sign-up";
import App from "./App.jsx";
import Account from "./page/account/Account.jsx";
import Errorpage from "./page/error/Errorpage.jsx";
import CategoryPage from "./page/CategoryPage/CategoryPage.jsx";
import Pdp from "./page/productDetails/Pdp.jsx";
import Checkout from "./page/checkout/Checkout.jsx";
import Login from "./page/login/Login.jsx";
import Wishlist from "./page/wishlist/Wishlist.jsx";

const router = createBrowserRouter([
  {
    path: "/home",
    element: <Home />,
  },
  {
    path: "/home/about",
    element: <About />,
  },
  {
    path: "/home/contact",
    element: <Contact />,
  },
  {
    path: "/home/cart",
    element: <Cart />,
  },
  {
    path: "/home/sign-up",
    element: <Signup />,
  },
  {
    path: "/home/favorites",
    element: <Favorites />,
  },
  {
    path: "/home/wishlist",
    element: <Wishlist />,
  },
  {
    path: "/home/categorypage/:id",
    element: <CategoryPage />,
  },
  {
    path: "/home/productdetailpage/:id",
    element: <Pdp />,
  },
  {
    path: "/home/checkout",
    element: <Checkout  />,
  },
  {
    path: "/home/account",
    element: <Account  />,
  },
  {
    path: "/home/error",
    element: <Errorpage />,
  },
  {
    path: "/home/log-in",
    element: <Login />,
  },
  {
    path: "/home/searchresults",
    element: <SearchResults />,
  }
]);


ReactDOM.createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <App />
  </BrowserRouter>
);
