import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";
import React from 'react'
import bannerHero1 from "/banner_Hero1.png";
import bannerHero2 from "/banner_Hero2.png";
import bannerHero3 from "/banner_Hero3.png";
import bannerHero4 from "/Screenshot2026-04-28151321.png";
import bannerHero6 from "/Screenshot2026-04-28232835.png";
import bannerHero7 from "/Screenshot2026-04-28232849.png";
import "./index.css";
function HeroSlider() {
  return (
    <>
      <div className="hero">
        <div className="container">

          <Swiper
            loop={true}
            autoplay={{
              delay: 2500,
              disableOnInteraction: false,
            }}
            pagination={true}
            modules={[Pagination, Autoplay]}
            className="mySwiper"
          >
            <SwiperSlide>
              <div className="content"></div>
              <img src={bannerHero1} alt="slider hero 1" />
            </SwiperSlide>

            <SwiperSlide>
              <div className="content"></div>
              <img src={bannerHero2} alt="slider hero 1" />
            </SwiperSlide>

            <SwiperSlide>
              <div className="content"></div>
              <img src={bannerHero3} alt="slider hero 1" />
            </SwiperSlide>
            <SwiperSlide>
              <div className="content"></div>
              <img src={bannerHero4} alt="slider hero 1" />
            </SwiperSlide>
            <SwiperSlide>
              <div className="content"></div>
              <img src={bannerHero6} alt="slider hero 1" />
            </SwiperSlide>
            <SwiperSlide>
              <div className="content"></div>
              <img src={bannerHero7} alt="slider hero 1" />
            </SwiperSlide>
          </Swiper>
        </div>
      </div>
    </>
  );
}

export default HeroSlider;
