import React from 'react'


export default function FavoritesContext() {
  return (
    <div>FavoritesContext</div>
  )
}

