import React from 'react'
import { RiAccountCircleFill } from "react-icons/ri";
import { LuShoppingBag } from "react-icons/lu";
import { MdCancel } from "react-icons/md";
import { CiStar } from "react-icons/ci";
import { CiLogout } from "react-icons/ci";
function addl() {
  return (
<div>
<RiAccountCircleFill /> <a href='/home/account'>Manage My Account</a>
<LuShoppingBag /> <a href='/home/account'>My Order</a>
<MdCancel /> <a href='/home/account'>My Cancellations</a>
<CiStar /> <a href='/home/account'>My Reviews</a>
<CiLogout /> <a href='/home/login'>Logout</a>
</div>
  )
}

export default addl