import { Routes, Route } from "react-router-dom";
import React from 'react'
import Home from "./page/home/Home";
import Contact from "./page/contact/Contact";
import Cart from "./page/cart/Cart";
import ScrollToTop from "./components/Scroll-to-top/ScrollToTop";
import About from "./page/about/About";
import SearchResults from "./page/SearchResults";
import Favorites from "./page/favorites/Favorites";
import Signup from "./page/sign-up/Sign-up";

import "./index.css";
function App() {
  return (
    <div>

      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/search" element={<SearchResults />} />
        <Route path="/favorites" element={<Favorites />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/about" element={<About />} />
        <Route path="/sign-up" element={<Signup />} />
      </Routes>
    </div>
  );
}
export default App;